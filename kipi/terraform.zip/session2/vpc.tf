locals {
    dish1 = "vadapav"
}