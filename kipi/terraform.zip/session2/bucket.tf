locals {
  env = "qa"
  env1 = "dev1"
  location = "mumbai"
}


resource "aws_s3_bucket" "b1" {
  bucket = var.bname
  tags = {
    Name = local.env
    env = local.location
    dish = local.dish1
  }
}
resource "aws_s3_bucket" "b2" {
  bucket = "vadapav-${var.bname}"
  tags = {
    Name = "test"
    env  = "dev1"
  }
}

resource "aws_s3_bucket" "b3" {
  bucket = "samosa-${var.bname}"
  tags = {
    Name = "kip1"
    env  = "qa"
  }
}

resource "aws_s3_bucket" "b4" {
  bucket = "samosa14-${var.bname}"
  tags = {
    Name = "kip1"
    env  = "qa"
  }
}


# import {
#   to = aws_s3_bucket.b2
#   id = "vadapav-${var.bname}"
# }