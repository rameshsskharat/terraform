akey    = "AKIVGHWT46"
skey    = "3WYjnXtIt1LTtDM"
region  = "ap-south-1"
bname   = "demo1-kipi-1"
sname   = ["kipi-s1", "kip-s2", "kipi-3"]
vpcname = "nothing"
env = {
  "dev" = "t2.micro"
  "qa"  = "t2.nano"
}
