terraform {
  required_providers {
    aws = {
      source = "hashicorp/aws"
    version = "6.36.0" }
  }
  # backend "s3" {
  #   bucket       = "trainer-terraform-state-bucket-17032026"
  #   key          = "terraform/remote/s3/terraform.tfstate"
  #   region       = "ap-south-1"
  #   use_lockfile = true
  #  }
}
provider "aws" {
  # Configuration options
  access_key = var.akey
  secret_key = var.skey
  region     = var.region
}
