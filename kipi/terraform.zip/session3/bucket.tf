resource "aws_s3_bucket" "b1" {
  provider = aws.cust1
  bucket   = "${var.bname}-${terraform.workspace}-vadapav"
}

resource "aws_s3_bucket" "b2" {
  provider = aws.cust2
  bucket   = "${var.bname}-${terraform.workspace}-vadapav1"
}

output "name-of-bucket" {
  value = aws_s3_bucket.b1.bucket
}
