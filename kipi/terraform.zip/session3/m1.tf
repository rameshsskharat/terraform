module "vpc" {

  source  = "terraform-aws-modules/vpc/aws"
  version = "6.6.0"
}

module "ec2" {

  source   = "kharatramesh/ec2/modules"
  version  = "1.0.0"
  itype    = "t2.micro"
  name     = "reusingModules"
  akey     = var.akey
  skey     = var.skey
  location = var.region
}