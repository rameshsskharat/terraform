terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "6.37.0"
    }
  }
}

terraform { 
  cloud { 
    
    organization = "kipi1" 

    workspaces { 
      name = "kipiworkspace1" 
    } 
  } 
}
provider "aws" {
  # Configuration options
  access_key = var.akey
  secret_key = var.skey
  region     = var.location
}