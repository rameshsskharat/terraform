variable "akey" {
  description = "access key"
  type        = string
  sensitive   = true
  default = ""
}
variable "skey" {
  description = "secret key"
  type        = string
  sensitive   = true
  default = ""
}
variable "location" {
  description = "region"
  type        = string
  default = ""
}

# variable "ingress_rule" {
#   type = list(object({ port = number
#     proto = string
#     des   = string
#   }))
# }

# variable "bnames" { type = map(any) }
# variable "inames" { type = map(any) }
# variable "env" { type = string }


# variable "envdemo" {
#   type = map(object({
#     instance_type = string
#     instance_name = string
#   }))
# }
