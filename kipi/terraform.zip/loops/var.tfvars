# akey     = "AKI6FKYYJG"
# skey     = "BW8cJjABn2w/5dG"
# location = "ap-south-1"
# ingress_rule = [{ port = 22, proto = "tcp", des = "this is ssh rule" },
#   { port = 80, proto = "tcp", des = "this is http rule" },
#   { port = 443, proto = "tcp", des = "this is https rule" },
#   { port = 25, proto = "tcp", des = "this is smtp rule" },
#   { port = 53, proto = "udp", des = "this is dns rule" },
#   { port = 3306, proto = "tcp", des = "this is mysql rule" },
#   { port = 8080, proto = "tcp", des = "this is tomcat rule" }
# ]

# # bnames = ["demo1", "demo2", "demo3", "dem04"]
# bnames = {

#   b1 = "demo1"
#   b2 = "demo2"
#   b3 = "demo3"
# }

# env    = "dev"
# inames = { i1 = "dev", i2 = "uat", i3 = "prod" }


# # envs = [{itype = "t2.micro",env="uat",name="uat1"},
# #         {itype = "t2.micro",env="dev",name="dev1"},
# #         {itype = "t3.medium",env="prod",name="prod1"}
# # ]

# envdemo = {

#   dev = {
#     instance_type = "t2.micro"
#     instance_name = "dev-server"
#   }
#   uat = {
#     instance_type = "t2.small"
#     instance_name = "uat-server"
#   }
#   qa = {
#     instance_type = "t3.micro"
#     instance_name = "qa-server"
#   }
#   prod = {
#     instance_type = "t3.large"
#     instance_name = "prod-server"
#   }
# }

