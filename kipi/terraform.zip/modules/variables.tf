variable "akey" {
  description = "access key"
  type        = string
  sensitive   = true
}
variable "skey" {
  type = string
}

variable "region" {
  type = string
}
variable "bname" {
  type = string
}

variable "vpcname" {
  type = string
}

variable "sname" {
  type = list(any)
}

variable "env" {
  type = map(any)
}