terraform {
  required_providers {
    aws = {
      source = "hashicorp/aws"
    version = "6.36.0" }

    azurerm = {
      source  = "hashicorp/azurerm"
      version = "4.64.0"
    }
  }
}

# provider "azure" {
#   alias = "az1"
#   features {}
# }

provider "aws" {
  alias = "cust1"
  # Configuration options
  access_key = var.akey
  secret_key = var.skey
  region     = var.region
}

provider "aws" {
  alias = "cust2"
  # Configuration options
  access_key = var.akey
  secret_key = var.skey
  region     = var.region
}
