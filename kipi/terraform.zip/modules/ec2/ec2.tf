resource "aws_instance" "vm1" {
    ami           = var.imagename
    instance_type = var.itype
    tags = {
        Name = "vm1"
    }
    
}