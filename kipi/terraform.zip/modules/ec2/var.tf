variable "itype" {
    type = string
    description = "please enter valid instance type as per region"
}

variable "imagename" {
    type = string
    description = "please enter valid image id as per region"
}

