module "vpcmodule" {
  source = "./vpc"

}

module "ec2Module" {
  source    = "./ec2"
  itype     = "t2.micro"
  imagename = "ami-0f559c3642608c138"
}

module "lbmodule" {
  source = "./lb"
  sname  = ["subnet-048d05b52f4219a99","subnet-0f65def9f4218c181"]
  lbname = "kipi-lb1"
}

