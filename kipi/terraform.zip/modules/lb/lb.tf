resource "aws_lb" "test" {
    name               = var.lbname
    internal           = false
    load_balancer_type = "application"
    subnets            = var.sname

    enable_deletion_protection = false

    tags = {
        Environment = "production"
    }
}