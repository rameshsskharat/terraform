variable "lbname" {
    type = string
    description = "loadbalancer Name"
} 

variable "sname" {
    type = list(string)
    description = "subnet name"
}