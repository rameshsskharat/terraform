resource "aws_vpc" "vpc1" {
    cidr_block = "91.91.91.0/24"
    tags = {
       Name = "vpc1"
    }
}

resource "aws_subnet" "s1" {
    vpc_id = aws_vpc.vpc1.id
    depends_on = [ aws_vpc.vpc1 ]
    cidr_block = "91.91.91.0/25"
}

resource "aws_subnet" "s2" {
    vpc_id = aws_vpc.vpc1.id
    depends_on = [ aws_vpc.vpc1 ]
    cidr_block = "91.91.91.128/25"
}