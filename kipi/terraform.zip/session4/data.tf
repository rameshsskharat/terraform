data "aws_vpc" "vpc1" {
  filter {
    name   = "tag:dish"
    values = ["vadapav"]
  }
}

data "aws_ami" "ami1" {
  most_recent = true
  filter {
    name   = "name"
    values = ["ubuntu-minimal/images/hvm-ssd-gp3/ubuntu-noble-24.04-amd64-minimal-*"]
  }
  owners = ["679593333241"]

}

data "aws_ec2_instance_types" "i1" {
  filter {
    name = "instance-type"
    # values = ["t2.micro", "t3.micro"]
    values = ["t*"]
  }

}
