resource "aws_key_pair" "k1" {
  key_name   = "key1"
  public_key = file("~/.ssh/id_rsa.pub")
}
