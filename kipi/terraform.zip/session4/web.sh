#!/bin/bash
sudo yum update -y
sudo yum install httpd -y
sudo cp /tmp/index.html /var/www/html/index.html
sudo systemctl restart httpd