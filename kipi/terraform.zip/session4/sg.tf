resource "aws_security_group" "allow_ssh" {
  depends_on = [ aws_key_pair.k1 ]
  name        = "allow_ssh"
  description = "Allow SSH inbound traffic"
  dynamic "ingress" {
    for_each = var.ingress_rule
    content {
      to_port     = ingress.value.port
      from_port   = ingress.value.port
      description = ingress.value.des
      protocol    = ingress.value.proto
      cidr_blocks = ["0.0.0.0/0"]
    }
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
