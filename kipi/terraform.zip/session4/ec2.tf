resource "aws_instance" "vm1" {
  depends_on = [ aws_security_group.allow_ssh,aws_key_pair.k1 ]
  # ami                    = "ami-0f559c3642608c138"
  ami = "ami-06c643a49c853da56"
  instance_type          = "t3.medium"
  key_name               = aws_key_pair.k1.key_name
  vpc_security_group_ids = [aws_security_group.allow_ssh.id]

  tags = {
    "Name" = "docker"
  }
  provisioner "file" {
    source      = "index.html"
    destination = "/tmp/index.html"
  }
  provisioner "file" {
    source      = "web.sh"
    destination = "/tmp/web.sh"
  }
  provisioner "local-exec" {
    command = "echo vm1 is successfully launched > vm1.txt"
  }
  provisioner "remote-exec" {
    inline = [
      "sudo chmod a+x /tmp/web.sh",
      "sudo cp /tmp/index.html /var/www/html/index.html",
      "sudo bash /tmp/web.sh"
    ]
  }
  connection {
    type        = "ssh"
    user        = "ec2-user"
    private_key = file("~/.ssh/id_rsa")
    host        = self.public_ip
  }
  # lifecycle {
  #   # prevent_destroy = true
  #   create_before_destroy = true
  # }
}

import {
  to = aws_instance.vm1
  id = "i-0b9d04aeb398b10a8"
}