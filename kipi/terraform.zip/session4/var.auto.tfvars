akey     = "AKIFKYYJG"
skey     = "Bpx8cJjABn2w/5dG"
location = "ap-south-1"
ingress_rule = [{ port = 22, proto = "tcp", des = "this is ssh rule" },
                { port = 80, proto = "tcp", des = "this is http rule" },
                { port = 443, proto = "tcp", des = "this is https rule" },
                { port = 25, proto = "tcp", des = "this is smtp rule" },
                { port = 53, proto = "udp", des = "this is dns rule" },
                { port = 3306, proto = "tcp", des = "this is mysql rule" },
                { port = 8080, proto = "tcp", des = "this is tomcat rule" }
            ]
