output "vpcid" {
  value = data.aws_vpc.vpc1.id
}

output "osbootmode" {
  value = data.aws_ami.ami1.boot_mode
}

output "instancetype" {
  value = data.aws_ec2_instance_types.i1.instance_types[6]

}

