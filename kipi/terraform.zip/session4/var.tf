variable "akey" {
  description = "access key"
  type        = string
  sensitive   = true
}
variable "skey" {
  description = "secret key"
  type        = string
  sensitive   = true
}
variable "location" {
  description = "region"
  type        = string
}

variable "ingress_rule" {
  type        = list(object({ port = number
  proto = string
  des = string 
  }))
}